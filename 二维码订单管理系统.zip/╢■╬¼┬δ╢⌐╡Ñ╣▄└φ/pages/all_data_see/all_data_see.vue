<template>
	<view>
		<view style="width: 100%;height: 200upx;position: fixed;top: 0px;background-color: #ffffff; z-index: 9999;">
			
		</view>
		<view class="top">
			<view class="top_input">
				<input type="text" v-model="searchText" placeholder="输入关键字" />
			</view>
			<view class="top_but" @click="findData">
				筛选
			</view>
		</view>
		<view class="top_but_all">
			<view type="default" :class="butClass[0]" @click="butChange(0)">网帽</view>
			<view type="default" :class="butClass[1]" @click="butChange(1)">地针</view>
			<view type="default" :class="butClass[2]" @click="butChange(2)">钩发</view>
			<view type="default" :class="butClass[3]" @click="butChange(3)">后处理</view>
			<view type="default" :class="butClass[4]" @click="butChange(4)">未发货</view>
		</view>
		<z-paging ref="paging" v-model="dataList" @query="queryList">
			<view style="width: 100%; height: 330upx;background-color: ;">
			
			</view>
			<view class="list_card">
				<view v-for="(item,index) in dataList" class="dd_ncard">
					<view class="card_top" @click="makeNowData(item,index)">
						<view class="but_index">
							{{ index }}
						</view>
						<view class="card_name">
							{{ item.dd_name }}
						</view>
						<view class="card_cc">
							{{ item.dd_cc }}
						</view>
					</view>
					<view class="card_model" @click="makeNowData(item,index)">
						<p style="color: #00172F;font-size: 40upx; width: 120upx;">款式:</p>
						{{ item.dd_ks }}
					</view>
					<view class="card_err">
						{{ item.err }}
					</view>
					<view class="card_but" @click="goSeeZt(item)">查看状态</view>
				</view>

			</view>

		</z-paging>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				dataList: [],
				butClass : ['top_but_all_view0','top_but_all_view0','top_but_all_view0','top_but_all_view0','top_but_all_view0'],
				searchArr : {},
				searchText : '',
				nowShoud : 0
			}
		},
		mounted() {
			// this.getAllData()
			const value = uni.getStorageSync('ZRF_138');
			if (value === '#$Absdasdqwd65562.da6.54.15426!$#@#$') {
				
			}else{
				this.url0 = '../_token/_token'
				this.url1 = '../_token/_token'
				uni.navigateTo({
					url : '../_token/_token'
				})
			}
		},
		methods: {
			async queryList(pageNo, pageSize) {
				if(this.nowShoud === 0){
					console.log(pageNo, pageSize)
					const db = uniCloud.database()
					let res = db.collection('dd_all')
					.where(this.searchArr)
					.orderBy('dd_time',"desc").skip((pageNo - 1) * pageSize).limit(pageSize).get()
					res.then(r => {
						this.$refs.paging.complete(r.result.data);
					})
				}else{
					console.log('运行这个了吗')
					uniCloud.callFunction({
						name: 'find_search_dd',
						data: {
							value: this.searchText,
						},
						success: (res) => {
							this.$refs.paging.complete(res.result.data);
						}
					})
				}
			},
			// 顶部按钮改变
			butChange(index){
				this.nowShoud = 0
				this.butClass.forEach( (r,i) => {
					if(index === i){
						// 变换
						if(r === 'top_but_all_view1'){
							this.butClass[i] = 'top_but_all_view0'
							
						}else{
							this.butClass[i] = 'top_but_all_view1'
						}
					}else{
						this.butClass[i] = 'top_but_all_view0'
					}
				})
				let a = 0;
				this.butClass.forEach( (r,i) => {
					if(r === 'top_but_all_view1'){
						a = i + 2
					}
				})
				if(a === 0){
					this.searchArr = {}
				}else if(a === 6){
					this.searchArr = {
						dd_now : 1
					}
				}else{
					this.searchArr = {
						dd_now : a
					}
				}
				this.$forceUpdate()
				this.queryList(1,10)
			},
			// 模糊查询
			findData() {
				this.nowShoud = 1
				this.queryList(1,10)
				uniCloud.callFunction({
					name: 'find_search_dd',
					data: {
						value: "1810"
					},
					success: (res) => {
						console.log(res)
					}
				})
			},
			goSeeZt(value) {
				uni.navigateTo({
					url: '../see_zt/see_zt?firstTime=' + value.dd_time + '&dd_id=' + value.dd_id
				})
			},
		},

	}
</script>

<style>
	.top {
		width: 100%;
		height: 150upx;
		background-color: #ffffff;
		display: flex;
		align-items: center;
		justify-content: space-around;
		position: fixed;
		top: 70upx;
		left: 0px;
		border-bottom: 1px solid #d6d6d6;
		z-index: 9999;
	}

	.top_input {
		/* background-color: #000000; */
		background-color: #f0f0f0;
		width: 70%;
		height: 100upx;
		border-radius: 30px;

	}

	.top_input input {
		width: 87%;
		/* background-color: #000000; */
		height: 100%;
		margin: 0 auto 0 auto;
		font-size: 38upx;
		font-weight: 700;
		color: #002448;
	}

	.top_but {
		width: 120upx;
		height: 80upx;
		border-radius: 20upx;
		background-color: #0077ef;
		color: #ffffff;
		font-size: 35upx;
		font-weight: 700;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.dd_ncard {
		width: 90%;
		margin: 10upx auto 20upx auto;
		border-bottom: 2px solid #0068d1;
		/* background-color: #002850; */
	}
	
	
	/* 筛选按钮 */
	.top_but_all{
		width: 100%;
		height: 100upx;
		position: fixed;
		top: 220upx;
		left: 0px;
		background-color: #ffffff;
		z-index: 9999;
		display: flex;
		justify-content: space-around;
		border-bottom: 1px solid #bfbfbf;
	}
	.top_but_all_view0{
		width: 18%;
		height: 70%;
		background-color: #d5d5d5;
		border-radius: 8px;
		font-size: 35upx;
		display: flex;
		align-items: center;
		justify-content: center;
		font-weight: 700;
		color: #00274f;
	}

	.top_but_all_view1{
		width: 23%;
		height: 70%;
		background-color: #337ad5;
		border-radius: 8px;
		font-size: 35upx;
		display: flex;
		align-items: center;
		justify-content: center;
		font-weight: 700;
		color: #ffffff;
	}
	
	.card_top {
		width: 100%;
		height: 100upx;
		display: flex;
		align-items: center;
	}

	/* new卡片 */
	.but_index {
		width: 70upx;
		height: 70upx;
		background-color: #007AFF;
		color: #ffffff;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 8px;
		font-size: 45upx;
		font-weight: 700;
	}

	.card_name {
		width: 450upx;
		font-size: 60upx;
		font-weight: 700;
		margin-left: 15upx;
		color: #00172f;
	}

	.card_cc {
		font-size: 30upx;
		font-weight: 700;
		color: #002f5e;
	}

	.card_model {
		font-size: 30upx;
		line-height: 2;
		color: #818181;
		font-weight: 550;
		display: flex;
		align-items: center;
	}

	.card_err {
		width: 100%;
		height: 50upx;
		display: flex;
		align-items: center;
		color: #ff0000;
		font-size: 35upx;
		font-weight: 700;
	}

	.card_but {
		width: 100%;
		height: 100upx;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 40upx;
		font-weight: 700;
		border-radius: 8upx;
		background-color: #d7e3f3;
		color: #316395;
		font-weight: 700;
	}
</style>
