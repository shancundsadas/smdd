<template>
	<view>
		<view class="top">
			<image src="../../static/icon/back.png" mode="" class="back" @click="backTop()"></image>
			<view class=""
				style="width: 680upx; display: flex;height: 100%;
			align-items: center;justify-content: center; font-size: 50upx;font-weight: 700;color: #007AFF;margin-right: 70upx;margin-top: 28upx;">
				修改状态
			</view>
		</view>
		<view class="but_all">

			<view style="background-color: #46d300;" @click="upAllData()">
				状态修改
			</view>

			<view @click="saoma()">
				扫码
			</view>

		</view>
		<view style="width: 100%;height:180upx;">

		</view>

		<view class="err_show" v-show="iferr">
			{{ nerr }}个上传失败（请检查网络或更换二维码后再次上传）
		</view>

		<!-- 扫码之后的数据 -->
		<view class="bb_data">

			<view v-for="(item,index) in dataArr" class="dd_ncard">
				<view class="card_top" @click="makeNowData(item,index)">
					<view class="but_index">
						{{ index }}
					</view>
					<view class="card_name">
						{{ item.name0 }}
					</view>
					<view class="card_cc">
						{{ item.cc }}
					</view>
				</view>
				<view class="card_model" @click="makeNowData(item,index)">
					<p style="color: #00172F;font-size: 40upx; width: 250upx;">款式:</p>
					{{ item.ks }}
				</view>
				<view class="card_err">
					{{ item.err }}
				</view>
				<button type="default" class="card_but" @click="goSeeZt(item)">查看状态</button>
			</view>

			<view style="width: 100%;height: 450upx;">

			</view>
		</view>

		<view class="up_ck" v-show="ifshow">
			<!-- 输出窗口 -->
		</view>
		<view class="up_ck_all_f" v-show="ifshow">
			<view class="up_ck_all">
				<view
					style="width: 100%; height: 100upx;display: flex;align-items: center;justify-content: flex-end;margin: 0px;">
					<image src="../../static/icon/guanbi.png" mode=""
						style="width: 70upx;height: 70upx;margin-right: 20upx;" @click="gb()"></image>
				</view>
				<view class="up_ck_all_view">
					客户姓名 ： <input type="text" value="" v-model="ewmData.name0" />
				</view>

				<view class="up_ck_all_view">
					尺寸 ： <input type="text" value="" v-model="ewmData.cc" />
				</view>

				<view class="up_ck_all_view">
					款式 ： <input type="text" value="" v-model="ewmData.ks" />
				</view>

				<view class="up_ck_all_view">
					自定义 ： <input type="text" value="" v-model="ewmData.zdy" />
				</view>
				<view class="up_ck_view">
					<!-- <button type="default" class="" @click="tianjiaDd" v-show="!ifXg">网帽制作</button>
					<button type="default" class="" @click="tianjiaDd" v-show="!ifXg">头发针织</button>
					<button type="default" class="" @click="tianjiaDd" v-show="!ifXg">地针</button>
					<button type="default" class="" @click="tianjiaDd" v-show="!ifXg">后处理</button> -->

					<view :class="viewClass[0]" @click="makeLiang(0)">
						网帽制作
					</view>
					<view :class="viewClass[1]" @click="makeLiang(1)">
						头发针织
					</view>
					<view :class="viewClass[2]" @click="makeLiang(2)">
						地针
					</view>
					<view :class="viewClass[3]" @click="makeLiang(3)">
						后处理
					</view>

				</view>

				<button type="default" class="buta" @click="tianjiaDd" v-show="!ifXg">添加</button>
				<view style="width: 100%; display: flex;">
					<button type="default" class="butac" style="background-color: #FF0000;" @click="shanchu"
						v-show="ifXg">删除</button>
					<button type="default" class="butac" @click="xiugai" v-show="ifXg">修改</button>
				</view>

			</view>
		</view>
		<!-- 加载旋钮 -->
		<loading ref="loading" :custom="false" :shadeClick="false" :type="1">
			<!-- <view class="test">自定义</view> -->
		</loading>

	</view>
</template>

<script>
	import loading from '../../components/xuan-loading/xuan-loading.vue'
	export default {
		data() {
			return {
				idArr: [],
				dataArr: [],
				ewmData: {
					dd_id: '',
					name0: '',
					name1: '',
					cc: '',
					ks: '',
					zdy: '',
					zt: '',
					firstTime : 0
				},
				ifshow: false,
				ifXg: false, //false为添加 true为修改
				nowDdid: 0,
				ii: 0,
				xiugaiData: {}, //记录当前要被修改的数据
				xiugaiIndex: 0,
				// 上传失败 则保存当前的信息
				errorData: [],
				iferr: false,
				nerr: 0,
				// 选择按钮的数组
				viewClass: ['up_ck_view_view0', 'up_ck_view_view0', 'up_ck_view_view0', 'up_ck_view_view0'],
				butValue: '',
			}
		},
		filters: {
			makezt(value) {
				if (value === 2) {
					return '网帽制作'
				} else if (value === 3) {
					return '头发针织'
				} else if (value === 4) {
					return '地针'
				} else {
					return '后处理'
				}

			}
		},
		components: {
			loading
		},
		onLoad(value) {

		},
		mounted() {

		},
		methods: {
			saoma() {
				// console.log('扫码')
				// 只允许通过相机扫码
				uni.scanCode({
					onlyFromCamera: true,
					success: res => {
						// 1.扫码成功 先查询是否有数据
						this.$refs.loading.open()
						console.log('怎么回事')
						this.ewmData.name0 = ''
						this.ewmData.name1 = ''
						this.ewmData.cc = ''
						this.ewmData.ks = ''
						this.ewmData.zdy = ''
						this.ewmData.zt = ''
						this.makeLiang(10)
						// console.log('条码类型：' + res.scanType);
						console.log('条码内容：' + res.result);
						if (res.result !== '') {
							//判断是不是已经扫码
							// 1.获取到id
							// 分割字符
							let newarr = res.result.split(',')
							// 验证一下(每个人的不一样)
							if (newarr[0] !== 'zrf') {
								this.$refs.loading.close()
								uni.showToast({
									title: '二维码格式错误',
									icon: 'none'
								})
								return
							}
							this.nowDdid = parseInt(newarr[1])
							//判断是不是已经扫了
							if (this.idArr.indexOf(this.nowDdid) === -1) {
								// 2.打开新的窗口 填写必要信息
								// 未扫码 验证获取数据
								const db = uniCloud.database()
								let res = db.collection('dd_all').where({
									dd_id: this.nowDdid
								}).get()
								res.then(r => {
									console.log('查询数据', r)
									if (r.result.data.length !== 0) {
										// 可以通过
										
										// console.log()
										console.log(r.result.data[0])
										this.ewmData = r.result.data[0].dd_data
										this.ewmData.firstTime = r.result.data[0].dd_time
										this.butValue = this.ewmData.zt
										this.makeLiang(this.butValue - 2)
										this.$refs.loading.close()
										this.ifshow = true
										this.ifXg = false
									} else {
										this.$refs.loading.close()
										uni.showToast({
											title: '改码还未上传',
											icon: 'none'
										})
									}
								})
							} else {
								this.$refs.loading.close()
								uni.showToast({
									title: '该二维码已扫',
									icon: 'error',
									time: 3000
								})
							}

						}

					}
				});
			},
			// 点击按钮让他亮起来
			makeLiang(index) {
				// console.log(index)
				this.viewClass.forEach((r, i) => {
					if (i === index) {
						this.viewClass[i] = 'up_ck_view_view1'
						this.butValue = i + 2
						this.$forceUpdate()
					} else {
						this.viewClass[i] = 'up_ck_view_view0'
						this.$forceUpdate()
					}
				})
			},

			//点击修改卡片数据
			makeNowData(item, index) {
				console.log(item, index)
				this.xiugaiData = item
				this.xiugaiIndex = index
				// 判断添加还是修改
				this.ifXg = true
				this.ewmData.name0 = item.name0
				this.ewmData.name1 = item.name1
				this.ewmData.cc = item.cc
				this.ewmData.ks = item.ks
				this.ewmData.zdy = item.zdy
				this.ewmData.zt = item.zt
				this.makeLiang(this.ewmData.zt - 2)
				// 打开遮蔽
				this.ifshow = true
			},

			xiugai() {
				console.log('修改数据', )
				let newArr0 = {}
				newArr0.name0 = this.ewmData.name0
				newArr0.name1 = this.ewmData.name1
				newArr0.cc = this.ewmData.cc
				newArr0.ks = this.ewmData.ks
				newArr0.dd_id = this.ewmData.dd_id
				newArr0.zt = this.butValue
				newArr0.zdy = this.ewmData.zdy
				this.dataArr[this.xiugaiIndex] = newArr0
				this.ifshow = false
			},
			tianjiaDd() {
				// 添加dd到队列
				let arr = {}
				arr.dd_id = this.nowDdid
				//判断是否以已经扫了
				this.idArr.push(this.nowDdid)
				arr.name0 = this.ewmData.name0
				arr.name1 = this.ewmData.name1
				arr.cc = this.ewmData.cc
				arr.ks = this.ewmData.ks
				arr.zdy = this.ewmData.zdy
				this.ewmData.zt = this.butValue //获取当前的值
				arr.zt = this.ewmData.zt
				arr.firstTime = this.ewmData.firstTime
				// 上传队列
				this.dataArr.push(arr)
				this.ifshow = false
			},
			// 返回上一个
			backTop() {
				// console.log('返回')
				uni.navigateBack({})
			},
			// 点击叉号
			gb() {
				this.ifshow = false
			},
			shanchu() {
				// 删除这个数据
				console.log()
				// this.dataArr[this.xiugaiIndex]删除这个数据
				console.log(this.xiugaiIndex)
				for (let a = this.xiugaiIndex; a < this.dataArr.length - 1; a++) {
					// 替换掉了
					this.dataArr[a] = this.dataArr[a + 1]
				}
				this.dataArr.pop() //删除最后一个元素
				// 删除id列表数据
				console.log(this.idArr)
				this.idArr.splice(this.xiugaiIndex, 1) //删除之后可以继续使用那个二维码 
				this.ifshow = false
			},

			upAllData() {
				// 判断有没有数据
				console.log(this.dataArr)
				if (this.dataArr.length === 0) {
					uni.showToast({
						title: "请先扫码",
						icon: 'error'
					})
					return
					
				}
				// 打开遮蔽曾
				this.$refs.loading.open()
				//调用云函数
				this.chuangjian()
			},
			// 跳转到转换装填
			goSeeZt(value){
				uni.navigateTo({
					url:'../see_zt/see_zt?firstTime='+value.firstTime+ '&dd_id='+value.dd_id
					// url:'../see_zt/see_zt?firstTime=1'
					
				})
			},
			chuangjian() {
				uniCloud.callFunction({
					name: 'make_new_zt',
					data: {
						alldd: this.dataArr
					},
					success: (res) => {
						// console.log(res)
						// 如果上传完成则 全部清空 否则保留错误可继续上传
						this.dataArr = res.result.error
						this.$refs.loading.close()
						if (res.result.code === 200) {
							// 成功
							this.iferr = false
							uni.showToast({
								title: '上传成功！',
								icon: 'success'
							})
						} else {
							// 出现错误
							this.iferr = true
							uni.showToast({
								title: '出错！重试或联系管理员',
								icon: 'none'
							})
						}
					},
					error: (err) => {
						console.log(err)
						this.$refs.loading.close()
						uni.showToast({
							title: '出错！重试或联系管理员',
							icon: 'none'
						})
					}
				})
			}


		}
	}
</script>

<style scoped>
	.top {
		width: 100%;
		height: 150upx;
		background-color: #ffffff;
		display: flex;
		align-items: center;
		position: fixed;
		top: 0px;
		z-index: 100;
		left: 0px;
	}

	/* 返回按钮 */
	.back {
		width: 70upx;
		height: 60upx;
		margin-left: 10upx;
		margin-top: 40upx;
	}

	/* 最大的两个图标 */

	.but_all {
		width: 100%;
		height: 300upx;
		display: flex;
		align-items: center;
		justify-content: space-around;
		position: fixed;
		top: 1200upx;
		left: 0px;
	}

	.but_all view {
		width: 250upx;
		height: 250upx;
		background-color: #007AFF;
		border-radius: 50%;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 45upx;
		font-weight: 700;
		color: #ffffff;
	}

	/* 存放数据 */
	.bb_data {
		width: 100%;
		z-index: 1;
	}

	.dd_card {
		width: 90%;
		height: 200upx;
		margin: 10upx auto 20upx auto;
		/* background-color: #007AFF; */
		border-bottom: 3px solid #0069d9;
		/* border-radius: 8px; */
		display: flex;
		flex-wrap: wrap;
	}

	.dd_card view {
		width: 40%;
		height: 50%;
		display: flex;
		align-items: center;
	}

	.up_ck {
		width: 100%;
		height: 100%;
		z-index: 1001;
		background-color: #959595;
		/* background: #c0c0c0; */
		opacity: 0.5;
		border-radius: 8px;
		position: fixed;
		top: 0px;
		display: flex;
		flex-direction: column;

	}

	.up_ck_all {
		/* opacity: 1; */
		z-index: 1002;
		width: 80%;
		margin: 0upx auto 10upx auto;
		background-color: #ffffff;
		border-radius: 8px;
		height: 1150upx;
	}

	.up_ck_all_f {
		z-index: 1003;
		width: 100%;
		position: fixed;
		top: 150upx;
	}

	.up_ck_all_view {
		width: 90%;
		margin: 0 auto 0 auto;
		display: flex;
		margin-bottom: 100upx;
		font-size: 30upx;
		font-weight: 700;
		/* align-items: center; */
		align-items: flex-end;
	}

	.up_ck_all input {
		width: 350upx;
		border-bottom: 1px solid #333333;
		height: 50upx;
		/* background-color: #007AFF; */
	}

	.buta {
		width: 60%;
		background-color: #007cf9;
		height: 80upx;
		font-size: 20px;
		display: flex;
		align-items: center;
		justify-content: center;
		font-weight: 700;
		color: #ffffff;
		margin-top: 20upx;

	}

	.butac {
		width: 230upx;
		background-color: #007cf9;
		height: 80upx;
		font-size: 20px;
		display: flex;
		align-items: center;
		justify-content: center;
		font-weight: 700;
		color: #ffffff;
		/* margin-top: 0 upx; */
	}

	.err_show {
		width: 100%;
		height: 100upx;
		background-color: #ff0000;
		color: #ffffff;
		font-size: 30upx;
		font-weight: 700;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.up_ck_view {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-around;

	}

	.up_ck_view_view0 {
		width: 40%;
		margin-bottom: 40upx;
		font-weight: 700;
		color: #002850;
		background-color: #f7f7f7;
		height: 80upx;
		border-radius: 8px;
		display: flex;
		align-items: center;
		justify-content: center;
		border: 1px solid #002b83;
	}

	.up_ck_view_view1 {
		width: 40%;
		margin-bottom: 40upx;
		font-weight: 700;
		color: #002850;
		background-color: #00bf00;
		color: #ffffff;
		height: 80upx;
		border-radius: 8px;
		display: flex;
		align-items: center;
		justify-content: center;
		border: 1px solid #003000;
	}

	.dd_ncard {
		width: 90%;
		margin: 10upx auto 20upx auto;
		border-bottom: 2px solid #0068d1;
		/* background-color: #002850; */
	}

	.card_top {
		width: 100%;
		height: 100upx;
		display: flex;
		align-items: center;
	}

	/* new卡片 */
	.but_index {
		width: 70upx;
		height: 70upx;
		background-color: #007AFF;
		color: #ffffff;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 8px;
		font-size: 45upx;
		font-weight: 700;
	}

	.card_name {
		width: 450upx;
		font-size: 60upx;
		font-weight: 700;
		margin-left: 15upx;
		color: #00172f;
	}

	.card_cc {
		font-size: 30upx;
		font-weight: 700;
		color: #002f5e;
	}

	.card_model {
		font-size: 30upx;
		line-height: 2;
		color: #818181;
		font-weight: 550;
		display: flex;
	}

	.card_err {
		width: 100%;
		height: 50upx;
		display: flex;
		align-items: center;
		color: #ff0000;
		font-size: 35upx;
		font-weight: 700;
	}
	.card_but{
		width: 100%;
		background-color:#e1eeff ;
		color: #316395;
		font-weight: 700;
	}
</style>
