<template>
	<view>
		<loading ref="loading" :custom="false" :shadeClick="false" :type="1">
			<!-- <view class="test">自定义</view> -->
		</loading>

		<view class="arr_all">

			<view class="arr_data">
				<p>名称：</p>
				<view>
					{{ dd_data.name0 }}
				</view>
			</view>

			<view class="arr_data">
				<p>ID：</p>
				<view>
					{{ dd_id }}
				</view>
			</view>

			<view class="arr_data">
				<p>尺寸：</p>
				<view>
					{{ dd_data.cc }}
				</view>
			</view>

			<view class="arr_data">
				<p>入库时间：</p>
				<view>
					{{ time | makeTime }}
				</view>
			</view>

			<view class="arr_card" v-for=" (item,index) in dd_zt_data" :key="index">
				<view class="arr_card_top">
					<view class="top_0">

					</view>
					<view class="top_1">
						{{ item.dd_data.zt | makezt}}
					</view>
					<view class="top_2">
						{{ item.dd_data.zdy }}
					</view>
				</view>
				<view class="card_time">
					{{ item.time | makeTime}}
				</view>
			</view>


		</view>
	</view>
</template>

<script>
	import loading from '../../components/xuan-loading/xuan-loading.vue'
	export default {
		data() {
			return {
				dd_id: '', //通过id进行查询
				dd_data : {},
				dd_zt_data: [],
				time: '',
			}
		},
		components: {
			loading
		},
		onLoad(value) {
			console.log('查看状态', value)
			this.time = parseInt(value.firstTime)
			this.dd_id = parseInt(value.dd_id)
			this.getHwData()
		},
		mounted(value) {
			this.$refs.loading.open()
		},
		filters: {
			// 显示当前装填
			makezt(value) {
				if (value === 2) {
					return '网帽制作'
				} else if (value === 3) {
					return '头发针织'
				} else if (value === 4) {
					return '地针'
				} else {
					return '后处理'
				}
			},
			// 时间戳处理
			makeTime(value) {
				var timestr = new Date(value);
				return timestr.getFullYear() + '-' + (timestr.getMonth() + 1) + '-' + timestr.getDate() + '  ' + timestr
					.getHours() + ':' + timestr.getMinutes()
			}
		},

		methods: {
			// 通过id获取货物信息
			getHwData() {
				const db = uniCloud.database()
				let res = db.collection('dd_zt').where({
					dd_id: this.dd_id
				}).orderBy('time', "desc").get()
				res.then(r => {
					this.dd_zt_data = r.result.data
					if(this.dd_zt_data.length === 0){
						this.dd_data = []
					}else{
						this.dd_data = this.dd_zt_data[0].dd_data
					}
					this.$refs.loading.close()
					
				})
			},
		}
	}
</script>

<style>
	.arr_all {
		width: 95%;
		margin: 0 auto 0 auto;
	}

	.arr_data {
		width: 100%;
		display: flex;
		height: 100upx;
		/* background-color: #00BF00; */
		align-items: center;
	}

	.arr_data p {
		font-size: 40upx;
		font-weight: 700;
		color: #001f3e;
	}

	.arr_card {
		border-bottom: 1px solid #00172F;
	}

	.arr_data view {
		font-size: 35upx;
		font-weight: 700;
		color: #003870;
	}

	.arr_card_top {
		width: 100%;
		height: 100upx;
		display: flex;
		align-items: center;
		/* background-color: #00172F; */
	}

	.top_0 {
		width: 40upx;
		height: 40upx;
		background-color: #007AFF;
		border-radius: 50%;
	}

	.top_1 {
		width: 200upx;
		font-size: 40upx;
		font-weight: 700;
		margin: 0 0 0 5%;
	}

	.top_2 {
		font-size: 35upx;
		font-weight: 700;
		margin: 0 0 0 30%;
	}

	.card_time {
		width: 100%;
		height: 80upx;
		font-size: 40uox;
		font-weight: 700;
		margin-left: 10%;
	}
</style>
