<template>
	<view>
		<P>id:{{ dd.dd_data.dd_id }}</P>
		<P>id:{{ dd.dd_data.name }}</P>
		<P>id:{{ dd.dd_data.other }}</P>
		<P>id:{{ dd.dd_data.phone }}</P>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				dd : {}
			}
		},
		onLoad(value) {
			console.log(value)
			this.dd= JSON.parse(value.arr)
			console.log(this.dd[0])
			this.dd = this.dd[0]
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
