<template>
	<view>
		<view class="" style="width: 100%; height: 400upx;">
			
		</view>
		<input type="text" value="" class="_input" v-model="token" placeholder="请输入密钥"/>
		<view type="default" class="_view_but" @click="butClick">确定</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				token : ''
			}
		},
		methods: {
			butClick(){
				if(this.token === '#$Absdasdqwd65562.da6.54.15426!$#@#$'){
					uni.setStorageSync('ZRF_138',this.token);
					// 通过
					uni.showToast({
						title:'密钥正确',
						icon:'none'
					})
					setTimeout(() => {
						uni.switchTab({
						    url: '/pages/index/index'
						});
					},1500)
				}else{
					uni.showToast({
						title:'失败，请联系管理员！',
						icon:'error'
					})
				}
			}
		}
	}
</script>

<style scoped>
	._input{
		width: 80%;
		height: 100upx;
		/* background-color: #00172F; */
		margin: 0 auto 0 auto;
		border-bottom: 1px solid #002850;
		font-size: 35upx;
		font-weight: 700;
	}
	._view_but{
		width: 250upx;
		height: 100upx;
		background-color: #00172F;
		margin: 100upx auto 0 auto;
		border-radius: 8px;
		background-color: #0073e7;
		color: #ffffff;
		font-size: 40upx;
		font-weight: 700;
		display: flex;
		align-items: center;
		justify-content: center;
	}
</style>
