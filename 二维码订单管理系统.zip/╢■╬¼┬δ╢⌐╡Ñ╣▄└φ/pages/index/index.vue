<template>
	<view class="">
		<view class="" style="width: 100%;height: 80upx;">
		<!-- 下载地址 ：  -->
		</view>
		<view class="index_all">
			<view class="" style="background-color: #48d900;" @click="goSaoMa">
				扫码上传
			</view>

			<view class="" style="margin-top: 100upx;" @click="gozt">
				扫码查看
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				url0 : '../push/push',
				url1 : '../search/search'
			}
		},
		onLoad() {
			// 验证是否已经有密钥
			const value = uni.getStorageSync('ZRF_138');
			if (value === '#$Absdasdqwd65562.da6.54.15426!$#@#$') {
				
			}else{
				this.url0 = '../_token/_token'
				this.url1 = '../_token/_token'
				uni.navigateTo({
					url : '../_token/_token'
				})
			}
		},
		methods: {
			goSaoMa() {
				uni.navigateTo({
					url: this.url0
				})
			},
			gozt() {
				uni.navigateTo({
					url: this.url1
				})
			}
		}
	}
</script>

<style scoped>
	.index_all {
		width: 100%;
		height: 500upx;
	}

	.index_all view {
		width: 90%;
		margin: 50upx auto 50upx auto;
		height: 300upx;
		background-color: #007AFF;
		border-radius: 8px;
		font-size: 60upx;
		font-weight: 700;
		display: flex;
		align-items: center;
		justify-content: center;
		color: #ffffff;
	}
</style>
