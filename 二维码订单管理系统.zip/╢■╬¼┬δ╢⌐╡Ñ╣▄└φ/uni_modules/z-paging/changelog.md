## 2.1.2（2022-01-11）
1.修复在nvue中使用`show-refresher-update-time`布局错乱的问题。  
2.修复在各个小程序平台中使用`show-refresher-update-time`时箭头变形闪动的问题。
