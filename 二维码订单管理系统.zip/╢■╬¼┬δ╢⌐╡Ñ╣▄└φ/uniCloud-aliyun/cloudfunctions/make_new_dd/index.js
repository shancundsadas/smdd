'use strict';
const db = uniCloud.database()
exports.main = async (event, context) => {
	//event为客户端上传的参数
	// console.log('event : ', event.alldd)
	let err = [] //存放错误的对象
	let success = 0 //正确个数
	let code = 0 //状态码
	// 查询设置循环遍历方法
	for(let a = 0; a < event.alldd.length; a++){
		let sarr = await simulateFetch(a,event.alldd[a])
		console.log(sarr)
		if(sarr == 1){
			// 成功
			success ++
		}else{
			// 失败
			err.push(sarr)
		}
	}
	if(success === event.alldd.length){
		code = 200 //全部成功
	}else{
		code = 100
	}
	
	return {
		code : code,
		success : success,
		error : err
	}
};

const simulateFetch = (i,arr) => {
	return new Promise((resolve, reject) => {
		// console.log('正在请求......');
		db.collection('dd_all').where({
				dd_id : arr.dd_id
			}).get()
			.then(res => {
				if(res.affectedDocs === 0){
					// 上传数据
					db.collection('dd_all').add({
						dd_id: arr.dd_id,
						dd_name: arr.name0,
						dd_cc : arr.cc,
						dd_ks : arr.ks,
						dd_zdy : '',
						dd_data: arr,
						dd_time: new Date().getTime(),
						dd_now: 1 //上传状态
					}).then( r => {
						console.log('成功',r)
						resolve(1);
					}).catch( e => {
						console.log('失败',e)
						arr.err = '新增失败'
						resolve(arr);
					})
				}else{
					// 有数据 这个数据作废 存放到err中
					console.log('失败')
					arr.err = '二维码已经被使用'
					resolve(arr);
				}
			})
	});
};
