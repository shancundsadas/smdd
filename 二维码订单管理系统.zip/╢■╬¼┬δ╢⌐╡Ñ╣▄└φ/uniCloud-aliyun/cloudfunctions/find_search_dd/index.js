'use strict';
const db = uniCloud.database();
exports.main = async (event, context) => {
	//event为客户端上传的参数
	console.log('event : ', event)
	//返回数据给客户端
	let text = event.value
	let dd_now = event.dd_now
	let search0 = {}
	const db = uniCloud.database()
	const dbCmd = db.command
	const res = await db.collection('dd_all')
		.where(
			dbCmd.or({
				dd_name : new RegExp(`${text}`),
			}, {
				dd_cc : new RegExp(`${text}`),
			}, {
				dd_ks : new RegExp(`${text}`),
			}, {
				dd_zdy : new RegExp(`${text}`),
			},{
				dd_now : dd_now
			})
		)
		.orderBy('dd_time',"desc")
		.get()

	return res
};
