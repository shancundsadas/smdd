'use strict';
const db = uniCloud.database()
exports.main = async (event, context) => {
	//event为客户端上传的参数
	console.log('event : ', event)
	let err = [] //存放错误的对象
	let success = 0 //正确个数
	let code = 0 //状态码
	// 设置循环遍历方法
	for (let a = 0; a < event.alldd.length; a++) {
		let sarr = await simulateFetch(a, event.alldd[a])
		console.log(sarr)
		if (sarr == 1) {
			// 成功
			success++
		} else {
			// 失败
			err.push(sarr)
		}
	}
	if (success === event.alldd.length) {
		code = 200 //全部成功
	} else {
		code = 100
	}

	return {
		code: code,
		success: success,
		error: err
	}
	//返回数据给客户端
	return event
};


const simulateFetch = (i, arr) => {
	return new Promise((resolve, reject) => {
		//先修改数据
		db.collection('dd_all').where({
				dd_id: arr.dd_id
			}).update({
				dd_name: arr.name,
				dd_cc : arr.cc,
				dd_ks : arr.ks,
				dd_zdy : arr.zdy,
				dd_data : arr,
				dd_now: arr.zt //上传状态
			})
			.then(res => {
				// 创建新数据订单
				db.collection('dd_zt').add({
					dd_id : arr.dd_id,
					time : new Date().getTime(),
					dd_user : arr.zdy,
					dd_now : arr.zt,
					dd_data : arr
				}).then( r => {
					// 成功
					resolve(1);
				}).catch( err => {
					arr.err = "创建状态失败，请重新上传"
					resolve(arr);
				})
				
			}).catch( err => {
				//失败 
				arr.err = "修改状态失败，请重新上传"
				resolve(arr);
			}) 
	});
};
