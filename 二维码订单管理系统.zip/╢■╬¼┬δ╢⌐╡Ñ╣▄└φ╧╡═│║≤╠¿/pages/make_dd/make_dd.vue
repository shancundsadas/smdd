<template>
	<view>
		<view class="" style="width: 100%; height: 50px;">

		</view>
		<uqrcode ref="uQRCode" :text="text" />
		<view class="now_all">

			<view class="">
				当前全部二维码 ： 999
			</view>

			<view class="">
				剩余可用二维码 ： 1
			</view>

			<view class="">
				剩余可用二维码 ： 1
			</view>
		</view>
		<!-- 创建一个画布 -->
		<!-- 21cm×29.7cm  A4纸张比率-->

		<!-- 这是二维码管理 -->
		<view class="but_all">
			<button type="default" @click="make()">创建100个</button>
			<button type="default">创建1000个</button>
			<button type="default">创建10000个</button>
		</view>
		<button type="default" @click="qingkong">清空数据表</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nowDdId: 0,
				text: "zrf,965",
			}
		},
		mounted() {
			// console.log('你好')
			this.getLast()
		},
		methods: {
			makeNext(){
				
			},
			make() {
				if (this.nowDdId !== 0) {
					this.nowDdId++
					// console.log('制造二维码')
					const db = uniCloud.database();
					db.collection("dd_all")
						.add({
							dd_id: this.nowDdId,
							dd_data: {},
							dd_time: 0,
							dd_now: 0
						})
						.then((res) => {
							// 生成一个二维码 保存dd_id 字符串
							this.text = this.nowDdId.toString()
							// console.log(this.text)
						})
						.catch((err) => {

						})
				}else{
					uni.showToast({
						title:'请稍等'
					})
				}

			},
			getLast() {
				const db = uniCloud.database()
				let res = db.collection('dd_all').limit(1).orderBy('time', "desc").get()
				res.then(r => {
					console.log(r.result.data[0].dd_id)
					this.nowDdId = r.result.data[0].dd_id
				})
			},
			qingkong(){
				const db = uniCloud.database()
				let res = db.collection('dd_all').remove()
				res.then( r => {
					console.log(r)
				})
			}
		}
	}
</script>

<style>
	.but_all {
		display: flex;
	}

	.but_all button {
		width: 250px;
	}

	.now_all {
		display: flex;
		justify-content: space-evenly;
		margin: 0 0 200px 0;
	}

	.now_all view {
		font-size: 25px;
	}
</style>
